package interfaces;

public interface Lander {
	boolean land();
}
