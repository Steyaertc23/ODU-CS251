
public class BicycleFactory {
	private int serialNo;
	
	public BicycleFactory() {
		serialNo = 0;
	}
	
	public Bicycle createBicycle() {
		return new Bicycle(serialNo++);
	}
}
