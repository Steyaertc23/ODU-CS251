
public class Dummy extends Entity {

	protected Dummy(double health, int entityID, double speed) {
		super(health, entityID, speed);
		// TODO Auto-generated constructor stub
	}

}
