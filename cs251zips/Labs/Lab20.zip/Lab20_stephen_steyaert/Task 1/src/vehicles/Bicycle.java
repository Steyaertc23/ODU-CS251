package vehicles;

public class Bicycle implements Rideable {

	@Override
	public void ride() {
		// TODO Auto-generated method stub

	}

}
