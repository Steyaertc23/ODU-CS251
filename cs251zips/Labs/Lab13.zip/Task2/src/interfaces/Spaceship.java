package interfaces;

public interface Spaceship {
	void move();
}
