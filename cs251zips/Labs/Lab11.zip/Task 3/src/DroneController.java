import java.util.ArrayList;

public class DroneController {
	
	private int maxNumberDrones;
	private int maxSignalRange;
	private int numberActiveDrones = 0;
	private int[] locationXY = new int[2];
	private ArrayList<Drone> systemDrones = new ArrayList<>();
	private ArrayList<Drone> systemDronesInRange = new ArrayList<>();
	
	public DroneController(int maxNumDrones, int x, int y, int maxSignal) {
		maxNumberDrones = maxNumDrones;
		locationXY[0] = x;
		locationXY[1] = y;
		maxSignalRange = maxSignal;
	}

	private double calculateDroneDistance(int[] droneLocation) {
		double distance = 0;
		int x = 0;
		int y = 0;
		
		x = droneLocation[0] - locationXY[0];
		y = droneLocation[1] - locationXY[1];
		
		distance = (double) Math.pow(x, 2) + (double) Math.pow(y, 2);
		distance = (double) Math.pow(distance, 1/2);
		
		
		return distance;
	}
	
	private void addDroneInRange(Drone drone) {
//		Drone[] temp = new Drone[systemDronesInRange.length + 1];
//        System.arraycopy(systemDronesInRange, 0, temp, 0, systemDronesInRange.length);
//		temp[systemDronesInRange.length] = drone;
//		systemDronesInRange = temp.clone();
		
		systemDronesInRange.add(drone);
	}
	private void resetDronesInRange() {
//		Drone[] temp = new Drone[1];
//		systemDronesInRange = temp;
		systemDronesInRange.clear();
	}
	
	
	public void scanRange() {
		resetDronesInRange();
		for (Drone drone : systemDrones){
			double distance = calculateDroneDistance(drone.getLocationXY());
			if (distance < maxSignalRange) {
				addDroneInRange(drone);	
			}
		}
	}
	
	private void addSystemDrone(Drone drone) {
//		Drone[] temp = new Drone[systemDrones.length + 1];
//        System.arraycopy(systemDrones, 0, temp, 0, systemDrones.length);
//		temp[systemDrones.length] = drone;
//		systemDrones = temp.clone();
		
		systemDrones.add(drone);
	}
	
	public boolean signalDrone(String msg, int id) {
		for (Drone drone : systemDrones)
			if(drone.getID() == id) {
				drone.setMessage(msg);
				return true;
			}
		return false;
	}
	
	public String signalDeploy(DroneDepot depot, int maxSpeed, int maxSignal, int maxPayload, String msg) {
		if (systemDrones.size() == maxNumberDrones) {
			return "Unable to deploy new Drone.";
		}
		int newDroneID = depot.createDrone(maxSpeed, maxSignal, maxPayload, msg);
//		System.out.println(newDroneID);
		Drone drone = depot.getDrone(newDroneID);
		if (drone == null)
			return "Error";
		addDroneInRange(drone);
		addSystemDrone(drone);
		
		numberActiveDrones++;
		return "Created Drone";
	}
	
	public ArrayList<Drone> getActiveDrones(){
		return systemDrones;
	}
	
	public ArrayList<Drone> getDronesInRange(){
		return systemDronesInRange;
	}

}
