package locations;

public class SolarSystem {
	private String systemName;
	
	public SolarSystem(String systemName) {
		this.systemName = systemName;
	}
	
	public String getSystemName() {
		return systemName;
	}
}
