
public class Box<T> {
	public T item;
	
	public Box(T item) {
		this.item = item;
	}
	
}
