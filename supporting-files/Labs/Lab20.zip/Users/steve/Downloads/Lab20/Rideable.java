

public interface Rideable {
	void ride();
}
