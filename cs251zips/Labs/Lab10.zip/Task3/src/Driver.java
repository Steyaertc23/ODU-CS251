
public class Driver {

	public static void main(String[] args) {
		
		int [] pos = {3, 5};
		DroneDepot depot = new DroneDepot(pos.clone());
		
//		System.out.println("Next Drone ID:" + DroneDepot.getNextDroneID());
		
		int droneOne = depot.createDrone(4, 30, 15, null);
//		System.out.println("Last Drone ID Created: " + droneOne);
		
//		System.out.println("Next Drone ID:" + DroneDepot.getNextDroneID());
		int droneTwo = depot.createDrone(5, 20, 17, null);
//		System.out.println("Last Drone ID Created: " + droneTwo);
		
//		System.out.println("Next Drone ID:" + DroneDepot.getNextDroneID());
		int droneThree = depot.createDrone(4, 10, 19, null);
//		System.out.println("Last Drone ID Created: " + droneThree);
		
		
		DroneDepot depotTwo = new DroneDepot(pos);
		
//		System.out.println("Next Drone ID:" + DroneDepot.getNextDroneID());
		
		int droneFour = depotTwo.createDrone(4, 30, 15, null);
//		System.out.println("Last Drone ID Created: " + droneFour);
		
//		System.out.println("Next Drone ID:" + DroneDepot.getNextDroneID());
		int droneFive = depotTwo.createDrone(5, 20, 17, null);
//		System.out.println("Last Drone ID Created: " + droneFive);
		
//		System.out.println("Next Drone ID:" + DroneDepot.getNextDroneID());
		int droneSix = depotTwo.createDrone(4, 10, 19, null);
//		System.out.println("Last Drone ID Created: " + droneSix);
		
		// Drones 1 and 4 have the same initialization except id numbers
		// Drones 2 and 5 have same initialization except id
		// Drones 3 and 6 have same initialization except id
		System.out.println(depot.getDrone(droneOne) == depotTwo.getDrone(droneFour));
		System.out.println(depot.getDrone(droneTwo) == depotTwo.getDrone(droneFive));
		System.out.println(depot.getDrone(droneThree) == depotTwo.getDrone(droneSix));
		
		
	}

}
