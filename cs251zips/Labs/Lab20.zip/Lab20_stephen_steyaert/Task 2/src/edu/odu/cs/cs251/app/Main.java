package edu.odu.cs.cs251.app;

import edu.odu.cs.cs251.vehicles.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Helicopter heli;
		Motorcycle moto;
		Airplane plane;
		Bus bus;
		Drivable d;
		Rideable r;
	}

}
