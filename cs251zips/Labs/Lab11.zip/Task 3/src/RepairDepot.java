import java.util.ArrayList;

public class RepairDepot {
	private int id = 1;
	private int[] depotLocation = new int[2];
	public ArrayList<RepairDrone> repairDrones = new ArrayList<>();
	
	
	public RepairDepot(int locationX, int locationY) {
		depotLocation[0] = locationX;
		depotLocation[1] = locationY;
	}
	
	class RepairDrone{
		private int[] location = new int[2];
		private int droneID;
		
		RepairDrone(int id, int[] deployLocation) {
			droneID = id;
			location = deployLocation.clone();
		}
		
		public void moveX(int dx) {
			location[0] += dx;
		}
		
		public void moveY(int dy) {
			location[1] += dy;
		}
		
		public void repair(Drone d) {
			 d.setTopSpeed( d.getTopSpeed() * 2);
		}
		
		public int[] getLocation() {
			return location.clone();
		}
		
	}
	
	public void repair(Drone d) {
		d.setTopSpeed( d.getTopSpeed() * 3);
	}
	
	public void DeployDrone() {
		RepairDrone d = new RepairDrone(id, depotLocation.clone());
		repairDrones.add(d);
		id++;
	}
}
