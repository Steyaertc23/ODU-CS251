import java.util.Scanner;

public class Main {
	
	static int Number_of_songs; 
	
	public static void main(String[] args) {
		String personwhowroteit, name;
		Song Song;
		Song[] ArrayList;
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the number of songs");
		Number_of_songs = in.nextInt();
		ArrayList = new Song[Number_of_songs];
		
		for (int Number_of_songs = 0; Number_of_songs < Number_of_songs; Number_of_songs++) {
			System.out.println("Enter the song name");
			name = in.nextLine();
			
			System.out.println("Enter the name of the person who wrote it");
			personwhowroteit = in.nextLine();
			
			Song = new Song(name);
			ArrayList[Number_of_songs] = Song;
			Song.Changeartist(Song.new personwroteit(personwroteit));
		}
		
		// Make it an arraylist for fun
		ArrayList<Song> songlist = Converter(ArrayList);
		System.out.println("Enter your name: ");
		name = in.nextLine();
		for (Song song : songlist) {
			song.print(name);
		}
	}
	
	public static ArrayList<Song> Converter(Song[] ArrayList) {
		ArrayList<Song> songs = new ArrayList<Song>();
		
		for (Song Song : ArrayList) {
			songs.add(Song);
		}
		
		return songs;
	}
}
