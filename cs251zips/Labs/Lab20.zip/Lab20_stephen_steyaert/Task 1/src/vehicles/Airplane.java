package vehicles;

public class Airplane implements Rideable{

	@Override
	public void ride() {
		// TODO Auto-generated method stub
		
	}

}
