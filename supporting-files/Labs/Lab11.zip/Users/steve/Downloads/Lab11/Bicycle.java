
class Bicycle {
	
	public int cadence;
	public int gear;
	public int speed;
	
	Bicycle() {
		cadence = 0;
		speed = 0;
		gear = 0;
	}
	
	Bicycle(int startCadence, int startSpeed, int startGear) {
		cadence = startCadence;
		speed = startSpeed;
		gear = startGear;
	}
	
	void setCadence(int newValue) {
		cadence = newValue;
	}
	
	void setGear(int newValue) {
		gear = newValue;
	}
	
	void applyBreak(int decrement) {
		speed -= decrement;
	}
	
	void speedUp(int increment) {
		speed += increment;
	}
	
	void gearUp() {
		gear++;
	}
	
	void gearDown() {
		gear--;
	}
	
}
