package vehicles;

public interface Rideable {
	void ride();
}
