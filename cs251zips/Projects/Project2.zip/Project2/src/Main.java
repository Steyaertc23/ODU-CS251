import utility.Utilites;

public class Main {

	public static void main(String[] args) {
		//Call The main menu method
		//TODO
		Utilites util = new Utilites();
		System.out.println("In between");
		util.viewMainMenu();

	}

}
