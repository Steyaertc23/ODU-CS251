
public interface Consumable {

	void use(Entity target);
}
