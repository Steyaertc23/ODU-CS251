
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pair<Integer, Integer> pairOne = new OrderedPair<>(0,1);
		Pair<Integer, String> pairTwo = new OrderedPair<>(1, "Hello");
		
		System.out.println(pairOne.getKey() + " " +  pairOne.getValue());
		System.out.println(pairTwo.getKey() + " " +  pairTwo.getValue());
	}

}
