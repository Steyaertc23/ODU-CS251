
public class Main {
	
	public static <T extends Comparable<T>> int doSomething(T[] arr, T elem) {
		int count = 0;
		for (T t : arr) {
			if (t.compareTo(elem) <= 0)
				++count;
		}
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] test = {"hello", "world", "this", "is", "a", "test"};
		System.out.println(doSomething(test, "hi"));
	}

}
