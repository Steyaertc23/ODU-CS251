package odu.edu.cs.cs251.dungeoncrawler.items;
import edu.odu.cs.cs251.dungeoncrawler.entities.Entity;

public interface Consumable {

	void use(Entity target);
}
