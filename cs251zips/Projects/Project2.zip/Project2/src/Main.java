import utility.Utilites;

public class Main {

	public static void main(String[] args) {
		//Call The main menu method
		//TODO
		Utilites util = new Utilites();
		util.viewMainMenu();

	}

}
