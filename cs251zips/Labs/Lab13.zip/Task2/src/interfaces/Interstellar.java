package interfaces;
import locations.SolarSystem;

public interface Interstellar extends Interplanetary {
	void jump(SolarSystem s);
}
