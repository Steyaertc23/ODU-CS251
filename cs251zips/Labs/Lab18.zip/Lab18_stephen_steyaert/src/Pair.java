
public interface Pair<K, V> {
	public V getValue();
	public K getKey();
}
