
public interface Interplanetary extends Spaceship {
	void jump(Planet p);
}
