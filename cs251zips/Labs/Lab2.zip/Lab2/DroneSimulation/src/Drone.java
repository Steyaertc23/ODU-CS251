
public class Drone {
	public int id, topSpeed, signalRange, payloadLimit;
	public int[] locationXY = new int[2];
	public String message;
	private int payload;
	
	public Drone() {
		id = -1;
	}
	
	public Drone(int idNum, int[] posXY, int maxSpeed, 
			     int maxSignalRange, int maxPayload, String msg) {
		
		id = idNum;
		locationXY = posXY;
		topSpeed = maxSpeed;
		signalRange = maxSignalRange;
		payloadLimit = maxPayload;
		message = msg;
		payload = 0;
	
	}
	
	public boolean loadDrone(int payloadWeight) {
		if (payload + payloadWeight > payloadLimit)
			return false;
		payload += payloadWeight;
		return true;
	}
	
	public String getCurrentPayload() {
		return payload + "cg";
	}
	
	public void moveX(int shamt) {
		locationXY[0] += shamt;
	}
	
	public void moveY(int shamt) {
		locationXY[1] += shamt;
	}
	
	public String getLocation() {
		String location = "X: " + locationXY[0] + ", Y: " + locationXY[1];
		
		return location;
	}
}
