package interfaces;
import locations.Planet;

public interface Interplanetary extends Spaceship {
	void jump(Planet p);
}
