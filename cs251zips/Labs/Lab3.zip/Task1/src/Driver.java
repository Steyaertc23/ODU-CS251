
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LousyBikeMechanic mech = new LousyBikeMechanic();
		mech.printBikes(new Bicycle(0,0,0), new Bicycle(1,1,1), new Bicycle(100,100,100));
	}

}
