
public interface Interstellar extends Interplanetary{
	void jump(SolarSystem s);
}
