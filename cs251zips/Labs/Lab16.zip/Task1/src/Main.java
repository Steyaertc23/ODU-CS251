
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BicycleListing listing = new BicycleListing(new Bicycle(9), BicycleListing.Condition.NEW, 200.90);
		
		System.out.println(listing.toString());
		
	}

}
