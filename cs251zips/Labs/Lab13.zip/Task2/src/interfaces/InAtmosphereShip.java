package interfaces;

public interface InAtmosphereShip extends Spaceship {
	
	boolean takeOff();
	
}
