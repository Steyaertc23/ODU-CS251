import Classes.Car;
import Classes.addToLocation;

/**
 * Demonstrate simple addToLocation and Car ADTs.
 */
class LaunchCars {
    /**
     * This is a non-trivial main function.
     *
     * @param args not used in this program
     */
    public static void main(String[] args)
    {
    	//Initializing the car company to car agency by creating an instance of Car class.
        Car BMW  = new Car("BMW");
        Car Mercedes   = new Car("Mercedes");
        Car Ferrari   = new Car("Ferrari");
        Car Porsche = new Car("Porsche");

        Car[] allCars = {BMW, Mercedes, Ferrari, Porsche};

        

        System.out.println();

    }
}