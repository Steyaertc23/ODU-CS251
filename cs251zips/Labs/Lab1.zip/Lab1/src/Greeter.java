import java.util.Scanner;


public class Greeter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter your name...");
		
		name = scanner.nextLine();
		
		System.out.println("Welcome to CS 251, " + name);
		
		scanner.close();
		
	}

}
