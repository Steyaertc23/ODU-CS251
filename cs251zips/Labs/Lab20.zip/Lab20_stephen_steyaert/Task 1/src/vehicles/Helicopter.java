package vehicles;

public class Helicopter implements Drivable, Rideable{

	@Override
	public void ride() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		
	}

}
