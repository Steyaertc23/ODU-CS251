package vehicles;

public interface Drivable {
	void drive();
}
