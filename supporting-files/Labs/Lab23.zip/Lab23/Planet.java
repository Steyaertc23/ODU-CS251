
public class Planet {
	String name;
	
	public Planet(String name) {
		this.name = name;
	}
}
