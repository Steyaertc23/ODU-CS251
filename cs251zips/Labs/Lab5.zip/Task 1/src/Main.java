import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {

		try {
			File file = new File ("."+ File.separator + "data"+ File.separator + "userEcho.txt");
			FileWriter writer = new FileWriter(file);
			System.out.println("Enter 10 lines:");
			for (int i = 0; i < 10; i++) {
				String input = scanner.next();
				writer.write(input + "\n");
			}
			System.out.println("Outputted to " + file.getPath());
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

}
