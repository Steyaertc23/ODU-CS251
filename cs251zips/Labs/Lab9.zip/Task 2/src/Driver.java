
public class Driver {

	public static void main(String[] args) {
		
		
//		int idNum, int[] posXY, int maxSpeed, 
//	     int maxSignalRange, int maxPayload, String msg
		int [] pos = {3, 5};
		Drone d = new Drone(5, pos.clone(), 4, 30, 3, null);
		
		RepairDepot repairDepot = new RepairDepot(5,3);
		System.out.println("Top Speed before repair: " + d.topSpeed);
		repairDepot.repair(d);
		System.out.println("Top Speed after RepairDepot repair: " + d.topSpeed);
		
		d = new Drone(5, pos.clone(), 4, 30, 3, null);
		
		System.out.println("Drone's speed has been reset.");
		
		repairDepot.DeployDrone();
		repairDepot.repairDrones.get(0).repair(d);
		
		System.out.println("Top Speed after RepairDrone repair: " + d.topSpeed);
		
		System.out.println("RepairDrone starting Location: \nX:" + repairDepot.repairDrones.get(0).getLocation()[0] + " Y:" + 
							repairDepot.repairDrones.get(0).getLocation()[1]);
		
		repairDepot.repairDrones.get(0).moveX(3);
		
		System.out.println("RepairDrone Location after moving X: \nX:" + repairDepot.repairDrones.get(0).getLocation()[0] + " Y:" + 
				repairDepot.repairDrones.get(0).getLocation()[1]);
		
		repairDepot.repairDrones.get(0).moveY(-7);
		
		System.out.println("RepairDrone Location after moving Y: \nX:" + repairDepot.repairDrones.get(0).getLocation()[0] + " Y:" + 
				repairDepot.repairDrones.get(0).getLocation()[1]);
		
	}

}
