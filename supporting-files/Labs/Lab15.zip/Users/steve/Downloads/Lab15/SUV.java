

public class SUV extends Car {
	public boolean active4WD;
	
	public SUV() {
		this.topSpeed = 0;
		this.MPG = 0;
		this.acceleration = 0;
		active4WD = false;
	}
	
	public SUV(int topSpeed, int MPG, int acceleration, boolean active4WD) {
		this.topSpeed = topSpeed;
		this.MPG = MPG;
		this.acceleration = acceleration;
		this.active4WD = active4WD;
	}
	

}
