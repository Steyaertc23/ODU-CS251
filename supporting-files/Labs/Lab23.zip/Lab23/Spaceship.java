
public interface Spaceship {

	void move();
}
