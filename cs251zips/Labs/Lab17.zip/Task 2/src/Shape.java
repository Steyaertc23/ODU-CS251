
abstract class Shape {
	abstract public double area();
	abstract public double perimeter();
	
}
