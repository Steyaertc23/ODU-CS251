
public class Sedan extends Car {

	enum Drivetrain_2WD{
		FWD, RWD;
	}
	
	public Drivetrain_2WD type;
	
	public Sedan() {
		this.topSpeed = 0;
		this.MPG = 0;
		this.acceleration = 0;
		type = Drivetrain_2WD.FWD;
	}
	
	public Sedan(int topSpeed, int MPG, int acceleration, Drivetrain_2WD type) {
		this.topSpeed = topSpeed;
		this.MPG = MPG;
		this.acceleration = acceleration;
		this.type = type;
	}
	
	@Override
	public void printInformation() {
		System.out.println("Type: " + type);
	}

}
