package ships;
import interfaces.InAtmosphereShip;

public class ZhuShip implements InAtmosphereShip {
	public ZhuShip() {
		
	}
	
	public boolean takeOff(){
		System.out.println("ZhuShip takes off");
		return true;
	}
}
