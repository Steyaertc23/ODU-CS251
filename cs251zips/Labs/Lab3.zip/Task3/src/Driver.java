import java.util.Random;

public class Driver {

	public static void main(String[] args) {
		
		DroneController controller = new DroneController(5, 0, 0, 10);
		DroneDepot depot1 = new DroneDepot(5,5);
		Random gen = new Random();
		
		String deployed = controller.signalDeploy(depot1,gen.nextInt(30), gen.nextInt(30), gen.nextInt(30), "msg");
		System.out.println(deployed);
		
		int direction;
		for(int i = 0; i < 20; i++) {
			Drone[] activeDrones = controller.getActiveDrones();
//			int number_active_drones = activeDrones.length;
			int number_drones_in_range = controller.getDronesInRange().length;
			for (int j = 0; j < number_drones_in_range-1; j++) {
				direction = gen.nextInt(2);
				if (direction == 0) {
					activeDrones[j].moveX(gen.nextInt(-2,2));
				}
				else {
					activeDrones[j].moveY(gen.nextInt(-2,2));
				}
			}
			controller.scanRange();
			int gened = gen.nextInt(2);
			if(gened == 0) {
				deployed = controller.signalDeploy(depot1, gen.nextInt(30), gen.nextInt(30), gen.nextInt(30), "");
				System.out.println(deployed);
			}
			else {
				controller.signalDrone("MSG", gen.nextInt(controller.getDronesInRange().length));
			}
			
			activeDrones = controller.getActiveDrones();
			System.out.println("Step " + i);
			System.out.println("DroneID\tposX\tposY\tMessage");
			for (Drone drone : controller.getActiveDrones()) {
				if (drone == null)
					break;
				System.out.println(drone.getID() + "\t" + drone.getLocationXY()[0] + "\t" + drone.getLocationXY()[1] + "\t" + drone.message);
			}
		}
	}

}
