
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BicycleFactory factoryOne = new BicycleFactory();
		
		Bicycle factoryOneBikeOne = factoryOne.createBicycle();
		Bicycle factoryOneBikeTwo = factoryOne.createBicycle();
		
		System.out.println("Factory 1 bike 1 serial number: " + factoryOneBikeOne.serialNo);
		System.out.println("Factory 1 bike 2 serial number: " + factoryOneBikeTwo.serialNo);
		
		BicycleFactory factoryTwo = new BicycleFactory();
		
		Bicycle factoryTwoBikeOne = factoryTwo.createBicycle();
		Bicycle factoryTwoBikeTwo = factoryTwo.createBicycle();
		
		System.out.println("Factory 2 bike 1 serial number: " + factoryTwoBikeOne.serialNo);
		System.out.println("Factory 2 bike 2 serial number: " + factoryTwoBikeTwo.serialNo);

	}

}
