
public class SolarSystem {
	String name;
	
	public SolarSystem(String name) {
		this.name = name;
	}
}
