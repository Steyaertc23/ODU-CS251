package interfaces;
import locations.Planet;

public interface Interplanetary {
	void jump(Planet p);
}
