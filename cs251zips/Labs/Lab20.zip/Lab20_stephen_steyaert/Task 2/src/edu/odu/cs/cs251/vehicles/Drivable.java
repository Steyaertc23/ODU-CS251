package edu.odu.cs.cs251.vehicles;

public interface Drivable {
	void drive();
}
