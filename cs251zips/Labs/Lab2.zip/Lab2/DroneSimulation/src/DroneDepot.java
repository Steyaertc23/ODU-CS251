import java.util.LinkedList;

public class DroneDepot {
	private LinkedList<Drone> drones = new LinkedList<Drone>();
	private int droneID = 1000;
	public int[] depotLocation;
	
	public DroneDepot(int[] depotXY) {
		depotLocation = depotXY;
	}
	
	public int createDrone(int maxSpeed, int maxSignal, int maxPayload, String msg) {
		Drone drone = new Drone(droneID, depotLocation.clone(), maxSpeed, maxSignal, maxPayload, msg);
		droneID++;
		drones.add(drone);
		return droneID-1;
		
	}
	
	private int searchForDrone(int droneId) {
		int first = 0;
		int last = drones.size() -1;
		int mid = 0;
		
		boolean found = false;
		
		while (first <= last && !found) {
			mid = (first + last) / 2;
			if (drones.get(mid).id == droneId) {
				found = true;
				break;
			}
			else {
				if (droneId > drones.get(mid).id)
					last = mid - 1;
				else
					first = mid + 1;
			}
		}
		
		
		if (found)
			return mid;
		return -1;
	}
	
//	private Drone searchForDrone(int droneId) {
//		Drone drone = new Drone();
//		for (int i = 0; i < drones.size(); i++) {
//			if (drones.get(i).id == droneId) {
//				return drones.get(i);
//			}
//		}
//		return drone;
//	}
	
	public boolean moveDroneX(int droneId, int shamt) {
		Drone drone = drones.get(searchForDrone(droneId));
		if (drone.id < 0) {
			return false;
		}
		drone.moveX(shamt);
		return true;
	}
	
	
	
	public boolean moveDroneY(int droneId, int shamt) {
		Drone drone = drones.get(searchForDrone(droneId));;
		if (drone.id < 0) {
			return false;
		}
		drone.moveY(shamt);
		return true;
	}
	
	public boolean loadDrone(int droneId, int payload) {
		Drone drone = drones.get(searchForDrone(droneId));;
		if (drone.id < 0)
			return false;
		
		boolean canLoad = drone.loadDrone(payload);
		return canLoad;
	}
	
	public String getDroneLocation(int droneId) {
		Drone drone = drones.get(searchForDrone(droneId));;
		if (drone.id < 0) {
			return "Drone does not exist";
		}
		return drone.getLocation();
	}
	
	public String getCurrentPayload(int droneId) {
		Drone drone = drones.get(searchForDrone(droneId));;
		if (drone.id < 0) {
			return "Drone does not exist";
		}
		return drone.getCurrentPayload();
	}
	
	
}