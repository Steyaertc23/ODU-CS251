
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Create two Drones at two different coordinates. Print their original locations, then
//		move them around using your implemented methods and print their final locations.
//		– Create one Drone Depot at any coordinate. Create a Drone using the Drone Depot
//		and print the drone's starting location. Move the Drone around using your
//		implemented methods, then print its final location.
//		– Choose one of your created Drones and demonstrate loading payloads onto the
//		drone using your implemented methods (including attempting to load too much
//		weight)
		
		//Creating drones
		int droneLocation[] = { 0, 5 };
		
		Drone droneOne = new Drone(100000, droneLocation.clone(), 20, 200, 50, "Hello");
		
		droneLocation[0] = 2;
		droneLocation[1] = 8;
		
		
		Drone droneTwo = new Drone(100004, droneLocation.clone(), 90, 20, 30, "Hello World");
		
		System.out.println("Drone One Starting Location: " + droneOne.getLocation());
		
		//Moving Drones
		droneOne.moveX(-3);
		droneOne.moveY(99);
		
		System.out.println("Drone Two Starting Location: " + droneTwo.getLocation());
		droneTwo.moveX(5);
		droneTwo.moveY(2);
		
		System.out.println("Drone One Final Location: " + droneOne.getLocation());
		
		System.out.println("Drone Two Final Location: " + droneTwo.getLocation());
		
		//Creating Depot
		int depotLocation[] = {0,0};
		
		DroneDepot depot = new DroneDepot(depotLocation.clone());
		
		//Creating Depot Drone
		int id = depot.createDrone(100, 50, 50, "Hello");
		
		System.out.println("Depot Drone Starting Location: " + depot.getDroneLocation(id));
		
		//Shifting Depot Drone
		boolean shiftedx = depot.moveDroneX(id, 3);
		boolean shiftedy = depot.moveDroneY(id, 9);
		if (!shiftedx || ! shiftedy)
			System.out.println("Drone Does not exist");
		
		System.out.println("Depot Drone Final Location: " + depot.getDroneLocation(id));
		
		//Loading Drone 1 (max load is 50 cg)
		
		int payload = 10;
		
		boolean loaded = droneOne.loadDrone(payload);
		
		if (loaded) {
			System.out.println("Drone One Loaded with " + droneOne.getCurrentPayload());
		}
		else {
			System.out.println("Unable to load Drone One with " + payload + "cg");
		}
		
		//Overloading Drone 2 (Max load is 30 cg)
		
		payload += 30;
		
		loaded = droneTwo.loadDrone(payload);
		
		if (loaded) {
			System.out.println("Drone Two Loaded with " + droneTwo.getCurrentPayload());
		}
		else {
			System.out.println("Unable to load Drone Two with " + payload + "cg");
		}
		
	}

}
