
public class MountainBike extends Bicycle {
	double suspension;
	
	public MountainBike() {
		super();
		suspension = 0.0;
	}
	
	public MountainBike(int speed, int gear, int cadence, double suspension) {
		this.gear = gear;
		this.speed = speed;
		this.cadence = cadence;
		this.suspension = suspension;
	}
	
	public double getSuspension() {
		return suspension;
	}
	
	public void setSuspension(double suspension) {
		this.suspension = suspension;
	}
}
