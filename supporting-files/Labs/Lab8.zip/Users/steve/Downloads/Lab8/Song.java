
public class Song {

	String name;
	public class personwhowroteit {
		String name;
		
		personwhowroteit(String name) {
			name = name;
		}
		
		void printer(String name) {
			System.out.println(name + " likes the song ");
			System.out.println(name);
			System.out.println(" by the artist: " + name);
		}
	}
	
	personwhowroteit artist;
	
	public Song() {
		name = "";
	}
	
	public Song(String name) {
		name = name;
	}
	
	public void ChangeName(String name) {
		name = name;
	}
	
	public String ReturnName() {
		return name;
	}
	
	public void Changeartist(personwhowroteit artist) {
		artist = artist;
	}
	
	public personwhowroteit personwhowroteitreturner() {
		return artist;
	}
	
	public void createsartistinplace(String name) {
		artist = new personwhowroteit(name);
	}
	
	public void print(String name) {
		artist.printer(name);
	}
}
