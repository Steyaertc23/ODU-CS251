package ships;
import interfaces.Lander;

public class CorvegaShip implements Lander {
	public CorvegaShip(){
	}
	
	public boolean land(){
		System.out.println("CorvegaShip lands");
		return true;
	}
}
