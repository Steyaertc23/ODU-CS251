package edu.odu.cs.cs251.vehicles;

public interface Rideable {
	void ride();
}
