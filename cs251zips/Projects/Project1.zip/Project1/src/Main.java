
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SeatingManagement manager = new SeatingManagement();
		manager.run();

		
	}

}
