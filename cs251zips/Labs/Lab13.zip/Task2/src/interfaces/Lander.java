package interfaces;

public interface Lander extends Spaceship {
	boolean land();
}
