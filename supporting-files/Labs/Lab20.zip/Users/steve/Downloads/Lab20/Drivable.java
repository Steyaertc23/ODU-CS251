

public interface Drivable {
	void drive();
}
