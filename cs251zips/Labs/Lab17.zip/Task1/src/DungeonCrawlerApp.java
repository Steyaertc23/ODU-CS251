import java.util.ArrayList;

public class DungeonCrawlerApp {

	public static void main(String[] args) {
		// TODO 

	}

}
