//import java.util.LinkedList;
import java.util.HashMap;

public class DroneDepot {
	private HashMap<Integer, Drone> drones = new HashMap<Integer, Drone>();
	private static int droneID = 0;
	public int[] depotLocation = new int[2];
	
	public DroneDepot(int[] depotXY) {
		depotLocation = depotXY;
	}
	
	public DroneDepot(int[] depotXY, int startingDroneID) {
		depotLocation = depotXY;
		droneID = startingDroneID;
	}
	public DroneDepot(int x, int y) {
		depotLocation[0] = x;
		depotLocation[1] = y;
	}
	
	public int createDrone(int maxSpeed, int maxSignal, int maxPayload, String msg) {
		Drone drone = new Drone(droneID, depotLocation.clone(), maxSpeed, maxSignal, maxPayload, msg);
		drones.put(droneID, drone);
		droneID++;
		return droneID-1;
		
	}
	
	public static int getNextDroneID() {
		return droneID;
	}
	
//	private int searchForDrone(int droneId) {
//		int first = 0;
//		int last = drones.size();
//		int mid = 0;
//		
//		boolean found = false;
//		
//		while (first <= last && !found) {
////			System.out.println(mid);
//			mid = (first + last) / 2;
//			if (drones.get(mid).id == droneId) {
//				found = true;
//				break;
//			}
//			else {
//				if (droneId > drones.get(mid).id)
//					last = mid - 1;
//				else
//					first = mid + 1;
//			}
//		}
		
		
//		if (found)
//			return mid;
//		return -1;
//	}
	
	public Drone getDrone(int droneId) {
			return drones.get(droneId);
	}
	
	public boolean moveDroneX(int droneId, int shamt) {
		Drone drone = drones.get(droneId);
		if (drone.id < 0) {
			return false;
		}
		drone.moveX(shamt);
		return true;
	}
	
	
	
	public boolean moveDroneY(int droneId, int shamt) {
		Drone drone = drones.get(droneId);
		if (drone == null) {
			return false;
		}
		drone.moveY(shamt);
		return true;
	}
	
	public boolean loadDrone(int droneId, int payload) {
		Drone drone = drones.get(droneId);
		if (drone == null)
			return false;
		
		boolean canLoad = drone.loadDrone(payload);
		return canLoad;
	}
	
	public String getDroneLocation(int droneId) {
		Drone drone = drones.get(droneId);
		if (drone == null) {
			return "Drone does not exist";
		}
		return drone.getLocation();
	}
	
	public String getCurrentPayload(int droneId) {
		Drone drone = drones.get(droneId);
		if (drone == null) {
			return "Drone does not exist";
		}
		return drone.getCurrentPayload();
	}
	
	
}