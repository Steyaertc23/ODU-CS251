import java.util.Scanner;
import java.util.regex.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try(Scanner scan = new Scanner(System.in)){
			System.out.println("Enter a regular expression");
			String regex = scan.nextLine();
			
			/// Compile the pattern
			
			
			System.out.println("Enter some strings");
			System.out.println("Enter -exit- to end the program");
			System.out.println("Enter -new- to write a different regex");
			while(scan.hasNext()) {
				String compare = scan.nextLine();
				if (compare.equals("-exit-")) {
					break;
				}
				
				else if (compare.equals("-new-")) {
					System.out.println("Enter a regular expression");
					regex = scan.nextLine();
					/// Compile the pattern
					
					System.out.println("Enter some strings");
				}
				
				else {		
					/// Compare using a Matcher
					
					/// Print whether it matches or not
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
