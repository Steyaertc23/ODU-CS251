
public interface Interstellar_v2 extends Interstellar {
	boolean checkStatus(int limit);
	
}
