import java.util.Scanner;

public class Greeter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
		Scanner in; 
		
		System.out.println("Enter your name");
		in = new Scanner(System.in);
		
		name = in.nextLine();
		
		System.out.println("Welcome to CS251, " + name);
		
		in.close();
	}

}
