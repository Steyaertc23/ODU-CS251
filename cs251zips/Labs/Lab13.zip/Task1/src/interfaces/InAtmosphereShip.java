package interfaces;

public interface InAtmosphereShip {
	

	boolean takeOff();
}
